RAIL SAFE OFFLINE WEBSITE

Files:
- index.html: Rail Safe website
- service-worker.js: offline caching
- manifest.json: PWA information

Deployment:
Upload the entire folder to Netlify. Keep all three website files in the same folder.
Open the HTTPS Netlify URL once while online so the service worker can cache the site.
Then test again after turning off Wi-Fi and mobile data.

Note: a first-ever QR scan on a completely new phone with no network cannot download a remote website.
